import React from 'react'

import styles from './thelandingpage.module.css'

const THELANDINGPAGE = (props) => {
  return (
    <div className={styles['container']}>
      <div className={styles['thelandingpage']}>
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/8c9be1ec-df38-4e28-bd66-aa4186a1b643?org_if_sml=1449367"
          alt="IMAGEandingPagebackgroundimage111"
          className={styles['ima-eanding-pagebackgroundimage']}
        />
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/54c7d695-b96a-4df9-b7c0-315d4961705b?org_if_sml=1364"
          alt="Bottombar113"
          className={styles['bottombar']}
        />
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/cb77593c-5b7d-49cb-99bd-4ad517634ca0?org_if_sml=12454"
          alt="Instagram118"
          className={styles['instagram']}
        />
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/50dcbaef-b40a-488e-93d1-d3994aebaeb6?org_if_sml=11422"
          alt="twitter44"
          className={styles['twitter']}
        />
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/52c0482f-3dd4-4ede-9fee-49e7af27a1c1?org_if_sml=11971"
          alt="Facebook120"
          className={styles['facebook']}
        />
        <img
          src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/708381ed-131f-484c-a081-a85749f179a8?org_if_sml=11095"
          alt="WhatsApp119"
          className={styles['whats-app']}
        />
        <span className={styles['text']}>
          <span>Contact Us</span>
        </span>
        <span className={styles['text02']}>
          <span>0234567890</span>
        </span>
        <span className={styles['text04']}>
          <span>WELCOME TO THABS</span>
        </span>
        <span className={styles['text06']}>
          <span>THE HAIR-TREATMENT APPOINTMENT BOOKING SYSTEM</span>
        </span>
        <button className={styles['button']}>
          <span className={styles['text08']}>
            <span>BOOK NOW</span>
          </span>
        </button>
        <div className={styles['thab-logo']}>
          <div className={styles['logo']}>
            <img
              src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/11956490-20f3-4791-afd3-c5e76bf37ca1/9f56cd0f-0ebb-4f1d-adee-001644ec30cc?org_if_sml=112560"
              alt="tafocandoi3x4BjmtJsunsplash1I114"
              className={styles['tafocandoi3x-bjmt-jsunsplash1']}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default THELANDINGPAGE

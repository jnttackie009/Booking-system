import React from 'react'

import styles from './theformspage.module.css'

const THEFORMSPAGE = (props) => {
  return (
    <div className={styles['container']}>
      <div className={styles['theformspage']}>
        <img
          src="/sharisirotnakom5yomhtf8eunsplash111221-c0fe-900h.png"
          alt="sharisirotnakoM5YoMhTf8Eunsplash111221"
          className={styles['sharisirotnako-m-yo-mh-tf-eunsplash11']}
        />
        <span className={styles['text']}>
          <span>Input The Your Details Below</span>
        </span>
        <img
          src="/logo6044-1yqx-200h.png"
          alt="Logo6044"
          className={styles['logo']}
        />
        <button className={styles['forms-page-next-button']}>
          <span className={styles['text02']}>
            <span>Next -&gt;</span>
          </span>
        </button>
        <div className={styles['form1']}>
          <div className={styles['formfieldcomponent']}>
            <span className={styles['text04']}>
              <span>Name</span>
            </span>
            <div className={styles['field']}>
              <span className={styles['text06']}>
                <span>Enter Name Here</span>
              </span>
            </div>
          </div>
          <div className={styles['formfieldcomponent1']}>
            <span className={styles['text08']}>
              <span>Telephone Number</span>
            </span>
            <div className={styles['field1']}>
              <span className={styles['text10']}>
                <span>Enter Telephone Number Here</span>
              </span>
            </div>
          </div>
          <div className={styles['formfieldcomponent2']}>
            <span className={styles['text12']}>
              <span>
                E-MAIL
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
            <div className={styles['field2']}>
              <span className={styles['text14']}>
                <span>Enter E-Mail Address Here</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default THEFORMSPAGE

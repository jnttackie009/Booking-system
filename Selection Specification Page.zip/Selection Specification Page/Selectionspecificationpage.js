import React from 'react'

import styles from './selection-specification-page.module.css'

const SelectionSpecificationPage = (props) => {
  return (
    <div className={styles['container']}>
      <div className={styles['selection-specification-page']}>
        <div className={styles['service-specificaion-page']}>
          <img
            src="/selectionspecificationbackgroundimage8516-pt6f-900h.png"
            alt="Selectionspecificationbackgroundimage8516"
            className={styles['selectionspecificationbackgroundimage']}
          />
          <div className={styles['thab-logo']}>
            <div className={styles['logo']}>
              <img
                src="/tafocandoi3x4bjmtjsunsplash11021-fpfs-200h.png"
                alt="tafocandoi3x4BjmtJsunsplash11021"
                className={styles['tafocandoi3x-bjmt-jsunsplash1']}
              />
            </div>
          </div>
          <div className={styles['formfieldcomponent']}></div>
          <span className={styles['text']}>
            <span>Have Custom or Additional Requests?</span>
          </span>
          <span className={styles['text2']}>
            <span>Provide More Information In The Input Box Below</span>
          </span>
          <div className={styles['formfieldcomponent1']}>
            <div className={styles['field']}>
              <span>
                <span>
                  This is supposed to represent the text box the customer can
                  specify details in
                </span>
                <br></br>
              </span>
            </div>
          </div>
          <button className={styles['forms-page-next-button']}>
            <span className={styles['text7']}>
              <span>Next -&gt;</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  )
}

export default SelectionSpecificationPage

import React from 'react'

import styles from './servicedisplaypage.module.css'

const SERVICEDISPLAYPAGE = (props) => {
  return (
    <div className={styles['container']}>
      <div className={styles['servicedisplaypage']}>
        <img
          src="/servicedisplaypagebackgroundimage4015-zm9-1800h.png"
          alt="servicedisplaypagebackgroundimage4015"
          className={styles['servicedisplaypagebackgroundimage']}
        />
        <span className={styles['text']}>
          <span>What Can We Do For You Today?</span>
        </span>
        <img
          src="/logo6045-al9-300h.png"
          alt="Logo6045"
          className={styles['logo']}
        />
        <div className={styles['wig-installation-feature-card']}>
          <span className={styles['text02']}>
            <span>Wig Installation</span>
          </span>
          <span className={styles['text04']}>
            <span>
              Effortless Glamour Awaits: Unleash your inner star with our expert
              wig installation service.
            </span>
          </span>
          <button className={styles['button']}>
            <span className={styles['text06']}>
              <span>Book Now</span>
            </span>
          </button>
          <div className={styles['available-service-icon']}>
            <img
              src="/wiginstallationiconi731-t21-200h.png"
              alt="wiginstallationiconI731"
              className={styles['wiginstallationicon']}
            />
          </div>
        </div>
        <div className={styles['wig-straightening-feature-card']}>
          <span className={styles['text08']}>
            <span>Wig Straightening</span>
          </span>
          <span className={styles['text10']}>
            <span>
              Unlock Silky Smooth Perfection: Our team offers a transformative
              experience, effortlessly turning your wigs into sleek, straight
              locks
            </span>
          </span>
          <button className={styles['button1']}>
            <span className={styles['text12']}>
              <span>Book Now</span>
            </span>
          </button>
          <div className={styles['available-service-icon1']}>
            <img
              src="/wigstraighteningiconi731-6rj-200w.png"
              alt="WigstraighteningiconI731"
              className={styles['wigstraighteningicon']}
            />
          </div>
        </div>
        <div className={styles['wig-making-feature-card']}>
          <span className={styles['text14']}>
            <span>Wig Making</span>
          </span>
          <span className={styles['text16']}>
            <span>
              Unleash your inner diva with our premier handcrafted,
              natural-looking wigs that invoke glamorous styles which enhance
              your unique beauty
            </span>
          </span>
          <img
            src="/availableserviceiconi731-g5if.svg"
            alt="AvailableServiceIconI731"
            className={styles['available-service-icon2']}
          />
          <button className={styles['button2']}>
            <span className={styles['text18']}>
              <span>Book Now</span>
            </span>
          </button>
        </div>
        <div className={styles['wig-revamping-feature-card']}>
          <span className={styles['text20']}>
            <span>Wig Revamping</span>
          </span>
          <span className={styles['text22']}>
            <span>
              Reignite Your Wig&apos;s Magic: Our expert team will breathe new
              life into your favorite wigs, restoring their beauty and infusing
              them with fresh style.
            </span>
          </span>
          <button className={styles['button3']}>
            <span className={styles['text24']}>
              <span>Book Now</span>
            </span>
          </button>
          <div className={styles['available-service-icon3']}>
            <img
              src="/wigrevampingiconi731-4txb-200h.png"
              alt="WigrevampingiconI731"
              className={styles['wigrevampingicon']}
            />
          </div>
        </div>
        <div className={styles['wig-curling-feature-card']}>
          <span className={styles['text26']}>
            <span>Wig Curling</span>
          </span>
          <span className={styles['text28']}>
            <span>
              Curly Perfection Awaits: Our team of talented stylists create
              stunning curls that adds volume, bounce, and allure to your wigs
              resulting in eye catching masterpieces
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
          <button className={styles['button4']}>
            <span className={styles['text30']}>
              <span>Book Now</span>
            </span>
          </button>
          <div className={styles['available-service-icon4']}>
            <img
              src="/wigcurlingiconi751-agz-200h.png"
              alt="WigcurlingiconI751"
              className={styles['wigcurlingicon']}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default SERVICEDISPLAYPAGE
